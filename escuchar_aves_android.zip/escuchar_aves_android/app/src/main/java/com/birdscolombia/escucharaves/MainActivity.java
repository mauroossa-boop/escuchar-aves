package com.birdscolombia.escucharaves;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String MERLIN_PACKAGE = "com.labs.merlinbirdid.app";
    private static final String MERLIN_SOUND_ID_ACTIVITY =
            "edu.cornell.birds.merlin.soundid.deeplink.SoundIdDeepLinksActivity";
    private static final Uri RECORD_URI = Uri.parse("merlinbirdid://record");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.openMerlinButton);
        button.setOnClickListener(v -> launchMerlinAudioId(false));

        // The app behaves like a shortcut: opening it immediately starts Merlin Audio ID.
        launchMerlinAudioId(true);
    }

    private void launchMerlinAudioId(boolean finishAfterLaunch) {
        Intent direct = new Intent(Intent.ACTION_VIEW, RECORD_URI);
        direct.setClassName(MERLIN_PACKAGE, MERLIN_SOUND_ID_ACTIVITY);

        try {
            startActivity(direct);
            if (finishAfterLaunch) finish();
            return;
        } catch (ActivityNotFoundException ignored) {
            // Fall back to the same Merlin deep link without forcing the class.
        }

        Intent fallback = new Intent(Intent.ACTION_VIEW, RECORD_URI);
        fallback.setPackage(MERLIN_PACKAGE);
        try {
            startActivity(fallback);
            if (finishAfterLaunch) finish();
        } catch (ActivityNotFoundException e) {
            TextView status = findViewById(R.id.statusText);
            status.setText(R.string.merlin_not_found);
            Toast.makeText(this, R.string.merlin_not_found, Toast.LENGTH_LONG).show();
        }
    }
}
