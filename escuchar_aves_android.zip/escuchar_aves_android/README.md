# Escuchar aves

Miniapp Android para abrir **Merlin Bird ID → Audio ID** directamente en modo de grabación.

## Qué hace

Al tocar el icono de la app o el widget, lanza un `Intent` con:

- Acción: `android.intent.action.VIEW`
- URI: `merlinbirdid://record`
- Paquete: `com.labs.merlinbirdid.app`
- Actividad: `edu.cornell.birds.merlin.soundid.deeplink.SoundIdDeepLinksActivity`

Estos son exactamente los valores que se comprobaron en el teléfono antes de crear este proyecto.

## Incluye

- Icono de app **Escuchar aves**.
- Apertura automática de Merlin Audio ID al tocar el icono.
- Widget 2×1 **ESCUCHAR AVES** para la pantalla de inicio.
- Pantalla de respaldo con botón manual si Merlin no pudiera abrirse.
- Flujo de GitHub Actions para generar `app-debug.apk` sin Android Studio.

## Compilar en Android Studio

1. Abre esta carpeta como proyecto.
2. Espera a que Android Studio descargue/sincronice Gradle y Android SDK 35.
3. `Build` → `Build APK(s)`.
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar con GitHub Actions

1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. Abre la pestaña `Actions`.
3. Ejecuta `Build Android APK`.
4. Descarga el artefacto `EscucharAves-debug-apk`.

## Nota

Esta miniapp no contiene código ni recursos de Merlin/Cornell. Solo abre una actividad y un deep link publicados por la app Merlin instalada en el teléfono.
